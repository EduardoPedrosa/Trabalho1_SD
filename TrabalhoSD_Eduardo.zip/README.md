# Métricas para avaliação de rede
Eduardo Miranda Pedrosa Filho - 201710145 <br>
Link do repositório:
https://github.com/EduardoPedrosa/Trabalho1_SD

